const mysql=require('mysql')
const express=require('express');
// const { create } = require('domain');
const bodyparser = require("body-parser");
var cors = require("cors");





// app.use(
//     express.urlencoded({
//         extended:true,
//     })
// );

const app = express();
app.use(cors());

// Use  body parser as middle ware
app.use(bodyparser.urlencoded({ extended: true }));

// app.use(app.json());
// app.use(app.urlencoded({extended:true}));


let connection = mysql.createConnection({
  host: "localhost",
  user: "mydbuser",
  password: "mydbuser",
  database: "mydb",
});
 
connection.connect((err)=>{
    if (err)console.log(err)
    else console.log("http://localhost:3001");;
});
app.get("/", (req, res)=>{
  res.end("databse")
  console.log("first")
})
app.get("/install", (req, res)=>{
// app.get("/", (req, res)=>{
    let message="table created"
let products=`CREATE TABLE if not exists products(
    product_id int(11) auto_increment,
    product_url varchar(255) not null,
    product_name varchar(255) not null,
    PRIMARY KEY (product_id)
)`;
let ProductDescription = `CREATE TABLE if not exists ProductDescription(
    description_id int auto_increment,
    product_id int(11) not null,
    product_brief_description TEXT not null,
    product_description TEXT not null,
    product_img varchar(255) not null,
    product_url varchar(255) not null,
    PRIMARY KEY (description_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
  )`;
let ProductPrice = `CREATE TABLE if not exists ProductPrice(
    price_id int auto_increment,
    product_id int(11) not null,    
    starting_price varchar(255) not null,
    price_range varchar(255) not null,
    PRIMARY KEY (price_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
  )`;
let orders = `CREATE TABLE if not exists orders(
    order_id int auto_increment,
    product_id int(11) not null,
    user_id int(11) not null,
    PRIMARY KEY (order_id)
)`;
let user = `CREATE TABLE if not exists user(
    user_id int auto_increment,
    user_name varchar(255) not null,
    user_password varchar(255) not null,
    PRIMARY KEY (user_id)
)`;
connection.query(products, (err, results, fields) => {
  if (err) console.log(err);
});
connection.query(ProductDescription, (err, results, fields) => {
  if (err) console.log(err);
});
connection.query(ProductPrice, (err, results, fields) => {
  if (err) console.log(err);
});
connection.query(orders, (err, results, fields) => {
  if (err) console.log(err);
});
connection.query(user, (err, results, fields) => {
  if (err) console.log(err);
});
res.end(message)
})



//insert data
app.post("/addProduct", (req, res)=>{
  console.table(req.body);
  let id = req.body.product_id;
  let url = req.body.product_url;
  let name = req.body.product_name;
  let img = req.body.product_img;
  let Brief = req.body.product_brief_description;
  let StartPrice = req.body.starting_price;
  let PriceRange = req.body.price_range;
  let Description = req.body.product_description;
  let uname=req.body.user_name;
  let pass=req.body.user_password;


  // To use it as a foreign key
    let addedProductId = 0;
  let sqlAddProducts = `INSERT INTO products(product_url, product_name)VALUES("${url}","${name}")`;
  connection.query(sqlAddProducts, function (err, result) {
    if (err) throw err;
    console.log("1 record inserted");
    // console.log(id);
    res.end("product is added");
  });

  connection.query(
  "SELECT * FROM products WHERE product_url= '"+url+"' ",
    // `SELECT * FROM products WHERE product_id=( "${id}") `,
    (err, rows, fields) => {
      // console.log(id);
      // console.log(rows);
    
      addedProductId = rows[0].product_id;
      console.log(addedProductId);
      if (err) console.log(err);
      if (addedProductId != 0) {
        let sqlAddToProductDescription =
          "INSERT INTO ProductDescription (product_id, product_brief_description, product_description, product_img, product_url) VALUES ('" +
          addedProductId +
          "', '" +
          Brief +
          "', '" +
          Description +
          "', '" +
          img +
          "', '" +
          url +
          "' )";
      

        let sqlAddToProductPrice =
          "INSERT INTO ProductPrice (product_id, starting_price, price_range) VALUES ('" +
          addedProductId +
          "', '" +
          StartPrice +
          "', '" +
          PriceRange +
          "')";
          let sqlAdduser=`INSERT INTO user (user_name,user_password) VALUES ("${uname}", "${pass}")`;
        connection.query(
          sqlAddToProductDescription,
          function (err, result) {
            if (err) throw err;
            console.log("Product description inserted");
          }
        );

        connection.query(sqlAddToProductPrice, function (err, result) {
          if (err) throw err;
          console.log("Product price inserted");
        });
        connection.query(sqlAdduser, function (err, result) {
          if (err) throw err;
          console.log("user inserted");
        });
      }
    }

  );
});

//Get all iphones

app.get(`/iphones`, (req, res) => {
  
  connection.query(
    "SELECT * FROM Products JOIN ProductDescription JOIN ProductPrice ON Products.product_id = ProductDescription.product_id AND Products.product_id = ProductPrice.product_id",
    (err, rows, fields) => {
      let iphones = { products: [] };
      iphones.products = rows;
      var stringIphones = JSON.stringify(iphones);
      if (!err) res.end(stringIphones);
      else console.log(err);
    }
  );
});






  
app.listen(3001, () => console.log("listening 3001"));