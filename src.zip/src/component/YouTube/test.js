import React from 'react'

function test() {
   console.log(fetch('../../../youtubepack.json')) 
    // fetch('../../../youtubepack.json')
  return (
    <div>
        console.log(fetch('../../../youtubepack.json')) 
    </div>
  )
}

export default test