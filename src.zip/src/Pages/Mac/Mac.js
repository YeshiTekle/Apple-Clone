import React, { Component } from "react";

class Mac extends Component {
  render() {
    return (
      <div>
        <section className="internal-page-wrapper top-100 bottom-100">
          <div className="container">
            <div className="row h-100 align-items-center justify-content-center text-center">
              <div className="col-12">
                <div className="title-wraper bold">Mac Page</div>
              </div>
            </div>
          </div>
        </section>
      </div>
    );
  }
}
export default Mac;
