import React from 'react'

export default function fun() {
  return (
    <div>fun</div>
  )
}
